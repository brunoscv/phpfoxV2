<?php
/**
 * [PHPFOX_HEADER]
 */

defined('PHPFOX') or exit('NO DICE!');

/**
 *
 *
 * @copyright		[MYPHPFOXMOD_COPYRIGHT]
 * @author  		cespiritual
 * @package  		Like System
 */
class profilebadge_Component_Block_style2 extends Phpfox_Component
{
	/**
	 * Class process method wnich is used to execute this component.
	 */
	public function process()
	{
		


	}
}

?>
