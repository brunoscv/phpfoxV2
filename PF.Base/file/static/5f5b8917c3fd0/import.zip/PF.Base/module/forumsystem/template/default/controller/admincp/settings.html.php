<?php 
defined('PHPFOX') or exit('NO APPLES!'); 
?>