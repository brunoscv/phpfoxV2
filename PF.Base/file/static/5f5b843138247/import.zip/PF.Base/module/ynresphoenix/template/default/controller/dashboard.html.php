<?php 
/**
 * [PHPFOX_HEADER]
 * 
 * @copyright		[YouNetCo]
 * @author  		YouNetCo
 * @package 		Ynclean
 * @version 		4.01
 */
 
defined('PHPFOX') or exit('NO DICE!'); 

?>
