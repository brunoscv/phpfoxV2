<?php

$aBundleScripts[] = [
    'tag-friends.js' => 'module_feed',
];