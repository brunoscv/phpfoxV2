<?php

if ($sClass == 'feed.comment') {
    $sClass = 'comment.comment';
}
