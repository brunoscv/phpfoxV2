<?php
defined('PHPFOX') or exit('NO DICE!');
?>
<div class="image_load parent-block" data-apply="row_image" data-src="{$image.image}" data-main="#page_core_index-visitor"></div>
{$content}