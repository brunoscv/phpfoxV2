<?php
$aPluginFiles[] = 'PF.Site/flavors/material/less/mt_includes/all-message.less';
$aPluginFiles[] = 'PF.Site/flavors/material/html/mail.controller.index.html.php';
$aPluginFiles[] = 'PF.Site/flavors/material/html/mail.controller.panel.html.php';
$aPluginFiles[] = 'PF.Site/flavors/material/html/profile.controller.points.html.php';
$aPluginFiles[] = 'PF.Site/flavors/material/hooks/component_controller_points_process_end.php';